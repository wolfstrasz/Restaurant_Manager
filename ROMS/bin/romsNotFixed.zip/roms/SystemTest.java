/**
 * 
 */
package roms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

/**
 * @author pbj
 *
 */
public class SystemTest extends TestBasis {   

    /*
     ***********************************************************************
     * BEGIN MODIFICATION AREA
     ***********************************************************************
     * Add all your JUnit tests for your system below.
     */
    
    
     
    @Test 
    public void cancelReadyUpLight() {
        logger.info(makeBanner("cancelReadyUpLight"));
        
        input("1 18:00, PassButton, pb, press");
        expect("1 18:00, PassLight, pl, viewSwitchedOff");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    /*
     * Tests for Phase 1:
     *  - Test OfficeKVM methods
     */
    
    @Test
    public void addToMenu_NewItem(){
        /* Tests if the item is added to the menu. */
        logger.info(makeBanner("OfficeKVM_addToMenu_NewItem"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 19:00, OfficeKVM, okvm, showMenu");
        
        expect("1 19:00, OfficeKVM, okvm, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " M1, Chicken Breast, 4.13,"
                + " M2, Meatballs, 0.99");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void addToMenu_UpdateItem(){
        /* Tests if it updates an item if we try to add an Item with the same ID. */
        logger.info(makeBanner("OfficeKVM_addToMenu_UpdateItem"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        input("1 19:00, OfficeKVM, okvm, showMenu");
        
        expect("1 19:00, OfficeKVM, okvm, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " D1, Coca-cola, 1.73,"
                + " M1, Chicken Breast, 4.13,"
                + " M2, Meatballs, 0.99");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void removeFromMenu_ExistingItem(){
        /* Tests if we remove an item when the item exists in the menu. */
        logger.info(makeBanner("OfficeKVM_removeFromMenu_ExistingItem"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 19:02, OfficeKVM, okvm, removeFromMenu, M1");
        input("1 19:00, OfficeKVM, okvm, showMenu");
        
        expect("1 19:00, OfficeKVM, okvm, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " M2, Meatballs, 0.99");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void removeFromMenu_NonExistingItem(){
        /* 
         * Tests Error Assertion if we try to remove 
         * an item that does not exists in the menu.
         */
        logger.info(makeBanner("OfficeKVM_removeFromMenu_NonExistingItem"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 19:02, OfficeKVM, okvm, removeFromMenu, M3");
        input("1 19:00, OfficeKVM, okvm, showMenu");
        
        expect("1 19:00, OfficeKVM, okvm, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " M1, Chicken Breast, 4.13,"
                + " M2, Meatballs, 0.99");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void addToMenu_NegativePrice(){
        /* 
         * Tests if an assertion error is sent 
         * when an item with negative price is to be added.
         */
        logger.info(makeBanner("OfficeKVM_addToMenu_NegativePrice"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, -0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        input("1 19:00, OfficeKVM, okvm, showMenu");
        
        expect("1 19:00, OfficeKVM, okvm, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " D1, Coca-cola, 1.73,"
                + " M1, Chicken Breast, 4.13");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }

    /*
     * Tests for Phase 2:
     *  - TableDisplay methods.
     */
    
    @Test
    public void showTableMenu(){
        /* 
         * Tests if we can display the menu on the table display.
         * Before and after an Item is added. 
         */
        logger.info(makeBanner("TableDisplay_showTableMenu"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 19:22, TableDisplay, td1, showMenu");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        input("1 5:00, TableDisplay, td1, showMenu");
        
        expect("1 19:22, TableDisplay, td1, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " M1, Chicken Breast, 4.13,"
                + " M2, Meatballs, 0.99");
        expect("1 5:00, TableDisplay, td1, viewMenu, tuples, 3,"
                + " ID, Description, Price,"
                + " D1, Coca-cola, 1.73,"
                + " M1, Chicken Breast, 4.13,"
                + " M2, Meatballs, 0.99");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void startOrder(){
        /* Tests if it creates a new order. */
        logger.info(makeBanner("TableDisplay_startOrder"));
        
        input("1 19:00, TableDisplay, td2, startOrder");
        input("1 20:00, TableDisplay, td2, showTicket");
        
        expect("1 20:00, TableDisplay, td2, viewTicket, tuples, 3, "
                + "ID, Description, Count");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    @Test
    public void startOrderExistingOrder(){
        /* Tests if it creates a new order over the last one. */
        logger.info(makeBanner("TableDisplay_startOrderExistingOrder"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:00, TableDisplay, td2, startOrder");
        input("1 20:00, TableDisplay, td2, showTicket");
        
        expect("1 20:00, TableDisplay, td2, viewTicket, tuples, 3, "
                + "ID, Description, Count");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void addMenuItem(){
        /* Tests if an item is added if it is a new one to the ticket. */
        logger.info(makeBanner("TableDisplay_addMenuItem"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 20:00, TableDisplay, td1, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "M2, Meatballs, 1");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void addMenuItem_Twice(){
        /* 
         * Tests if the quantity of an existing item is increased
         * when we add an item that is already in the ticket.
         */
        logger.info(makeBanner("TableDisplay_addMenuItem_Twice"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, D1");
        input("1 20:00, TableDisplay, td1, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "D1, Coca-cola, 1, "
                + "M2, Meatballs, 2");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    @Test
    public void addMenuItem_NonExisting(){
        /* 
         * Tests if error message is sent if we try
         * to add an item that does not exist to the ticket.
         */
        logger.info(makeBanner("TableDisplay_addMenuItem_NonExisting"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, D7");
        input("1 20:00, TableDisplay, td1, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "M2, Meatballs, 2");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    @Test
    public void removeMenuItem_Existing_CountMany(){
        /* 
         * Tests if the quantity of an existing item is decreased
         * when we remove an item that has quantity >1.
         */
        logger.info(makeBanner("TableDisplay_removeMenuItem_Existing_CountMany"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, D1");
        input("1 19:13, TableDisplay, td1, removeMenuItem, M2");
        input("1 20:00, TableDisplay, td1, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "D1, Coca-cola, 1, "
                + "M2, Meatballs, 1");
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void removeMenuItem_Existing_CountOne(){
        /*
         * Tests if the whole item is removed from the ticket list
         * when it has quantity = 1 and remove request is made.
         */
        logger.info(makeBanner("TableDisplay_removeMenuItem_Existing_CountOne"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, D1");
        input("1 19:13, TableDisplay, td1, removeMenuItem, D1");
        input("1 20:00, TableDisplay, td1, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "M2, Meatballs, 2");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void removeMenuItem_NonExisting(){
        /* 
         * Tests the assertion if we try to remove a non-existing item
         */
        logger.info(makeBanner("TableDisplay_removeMenuItem_NonExisting"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, D1");
        input("1 19:13, TableDisplay, td1, removeMenuItem, D1");
        input("1 19:25, TableDisplay, td1, removeMenuItem, D1");
        input("1 20:00, TableDisplay, td1, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "M2, Meatballs, 2");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void submitOrder(){
        /*
         * Tests if an order is successfully submited.
         */
        logger.info(makeBanner("TableDisplay_submitOrder"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Meatballs, 0.40");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, D1");
        input("1 19:13, TableDisplay, td1, removeMenuItem, D1");
        input("1 20:00, TableDisplay, td1, showTicket");
        input("1 19:20, TableDisplay, td1, submitOrder");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "M2, Meatballs, 2");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void payBill(){
        /*
         * Tests the payBill method of the table display.
         * Tests if it is connected to the expected cr and rp.
         */
        logger.info(makeBanner("TableDisplay_payBill()"));
        
        input("1 20:00, TableDisplay, td1, startOrder");
        input("1 20:02, TableDisplay, td1, submitOrder");
        input("1 21:30, TableDisplay, td1, payBill");
        input("1 21:32, CardReader, cr1, acceptCardDetails, SOMEDETAILS");
        input("1 21:33, BankClient, bc, acceptAuthorisationCode, SOMECODE");
        
        expect("1 21:30, TableDisplay, td1, approveBill, Total:, 0.00");
        expect("1 21:32, BankClient, bc, makePayment, SOMEDETAILS, 0.00");
        expect("1 21:33, ReceiptPrinter, rp1, takeReceipt, Total:, 0.00, AuthCode:, SOMECODE");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void noConnectionInTickets(){
        /*
         * Tests if two table displays control only their
         * own tickets and wrong functionality does not exist.
         */
        logger.info(makeBanner("Check if both displays use same ticket"));
        
        input("1 18:00, OfficeKVM, okvm, addToMenu, M1, Chicken Breast, 4.13");
        input("1 18:01, OfficeKVM, okvm, addToMenu, M2, Meatballs, 0.99");
        input("1 18:03, OfficeKVM, okvm, addToMenu, D1, Coca-cola, 1.73");
        
        input("1 19:01, TableDisplay, td1, startOrder");
        input("1 19:01, TableDisplay, td2, startOrder");
        
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td1, addMenuItem, M2");
        input("1 19:02, TableDisplay, td2, addMenuItem, M2");
        input("1 19:04, TableDisplay, td1, addMenuItem, D1");
        input("1 19:07, TableDisplay, td2, addMenuItem, M2");
        input("1 19:09, TableDisplay, td2, addMenuItem, M2");
        input("1 19:09, TableDisplay, td1, addMenuItem, D1");
        input("1 19:10, TableDisplay, td2, addMenuItem, M2");
        input("1 19:13, TableDisplay, td1, removeMenuItem, M2");
        
        input("1 20:00, TableDisplay, td1, showTicket");
        input("1 21:00, TableDisplay, td2, showTicket");
        
        expect("1 20:00, TableDisplay, td1, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "D1, Coca-cola, 2, "
                + "M2, Meatballs, 1");
        expect("1 21:00, TableDisplay, td2, viewTicket, tuples, 3, "
                + "ID, Description, Count, "
                + "M2, Meatballs, 4");
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    @Test
    public void noConnectionInTableDevices()
    {
        /* 
         * Tests if table devices use their own printers and card readers.
         */
        logger.info(makeBanner("Check if groups of table devices mismatch"));
        
        input("1 20:00, TableDisplay, td1, startOrder");
        input("1 20:02, TableDisplay, td1, submitOrder");
        input("1 20:00, TableDisplay, td2, startOrder");
        input("1 20:02, TableDisplay, td2, submitOrder");
        
        input("1 20:02, TableDisplay, td2, payBill");
        input("1 21:32, CardReader, cr2, acceptCardDetails, SOMEDETAILS");
        input("1 21:33, BankClient, bc, acceptAuthorisationCode, FirstPay");
        
        input("1 21:30, TableDisplay, td1, payBill");
        input("1 21:37, CardReader, cr1, acceptCardDetails, VISA");
        input("1 21:39, BankClient, bc, acceptAuthorisationCode, SecondPay");

        expect("1 20:02, TableDisplay, td2, approveBill, Total:, 0.00");
        expect("1 21:32, BankClient, bc, makePayment, SOMEDETAILS, 0.00");
        expect("1 21:33, ReceiptPrinter, rp2, takeReceipt, Total:, 0.00, AuthCode:, FirstPay");
        
        expect("1 21:30, TableDisplay, td1, approveBill, Total:, 0.00");
        expect("1 21:37, BankClient, bc, makePayment, VISA, 0.00");
        expect("1 21:39, ReceiptPrinter, rp1, takeReceipt, Total:, 0.00, AuthCode:, SecondPay");;
        
        runAndCheck();
        logger.info("End of test"  + '\n' + '\n');
    }
    
    /*
     * Phase 3 Tests:
     */
    
    /*
     @Test
     public void showRackAtTick(){}
     
     @Test
     public void indicateItemReady_Existing_First(){}
     
     @Test
     public void indicateItemReady_Existing_Last(){}
     
     @Test
     public void indicateItemReady_NonExisting(){}
     
     @Test
     public void cancelReadyUpLight(){}
     
     @Test
     public void testTick(){}
     
     */
   /*
    * Put all your JUnit system-level tests above.
    ***********************************************************************
    * END MODIFICATION AREA
    ***********************************************************************
    */

    
    
   /**
    * Set up system to be tested and connect interface devices to 
    * event distributor and collector. 
    * 
    * Setup is divided into two parts:
    * 
    * 1. Where IO device objects are created and connected to event
    *    distributor and event collector.
    *    
    * 2. Where core system implementation objects are created and 
    *    links are added between all the implementation objects and
    *    the IO device objects.
    *    
    * The first part configures sufficient IO device objects for all 3
    * implementation phases defined in the Coursework 3 handout.  It should 
    * not be touched. 
    * 
    * The second part here only gives the configuration for the demonstration
    * design.  It has to be modified for the system implementation.
    *   
    * 
    */
    @Override
    protected void setupSystem() {

        /* 
         * PART 1: 
         * - IO Device creation.  
         * - Establishing links between IO device objects and test framework objects.
         */
        
        
        /*
         * IO DEVICES FOR KITCHEN AREA
         * 
         * Create IO objects for kitchen.
         * Connect them to the event distributor and event collector.
         */
        
        KitchenDisplay display = new KitchenDisplay("kd");
        display.addDistributorLinks(distributor);
        display.setCollector(collector);
        
        Clock.initialiseInstance();
        Clock.getInstance().addDistributorLinks(distributor);
                
        TicketPrinter printer = new TicketPrinter("tp");
        printer.setCollector(collector);
      
        /* 
         * IO DEVICES FOR PASS
         */

        /*
         * Create IO objects for PASS
         * Connect them to the event distributor and event collector.
         */

        PassLight light = new PassLight("pl");
        light.setCollector(collector);
        
        PassButton button = new PassButton("pb");
        button.addDistributorLinks(distributor);
        
        
        // IO DEVICES FOR OFFICE
        
        // Create IO objects for office.
        // Connect them to the event distributor and event collector.
        
        OfficeKVM officeKVM = new OfficeKVM("okvm");
        officeKVM.addDistributorLinks(distributor);
        officeKVM.setCollector(collector);
        
        BankClient bankClient = new BankClient("bc");
        bankClient.addDistributorLinks(distributor);
        bankClient.setCollector(collector);
        
                
        // IO DEVICE FOR TABLES
        
        final int NUM_TABLES = 2;
        
        List<TableDisplay> tableDisplays = new ArrayList<TableDisplay>();
        List<ReceiptPrinter> receiptPrinters = new ArrayList<ReceiptPrinter>();
        List<CardReader> cardReaders = new ArrayList<CardReader>();
        
        for (int i = 1; i <= NUM_TABLES; i++) {
            
            String iString = Integer.toString(i);
            
            // Create IO objects for a table.
            // Connect to event distributor and collector
            
            TableDisplay tableDisplay = 
                    new TableDisplay("td" + iString);
            tableDisplay.addDistributorLinks(distributor);
            tableDisplay.setCollector(collector);
            tableDisplays.add(tableDisplay);
            
            
            ReceiptPrinter receiptPrinter = 
                    new ReceiptPrinter("rp" + iString);
            receiptPrinter.setCollector(collector);
            receiptPrinters.add(receiptPrinter);
            
            CardReader cardReader = 
                    new CardReader("cr" + iString);
            cardReader.addDistributorLinks(distributor);
            cardReaders.add(cardReader);
            
           
        }
        
        /* 
         * PART 2: 
         * - Implementation object creation. 
         * - Establishing links between different implementation 
         *   objects and IO Device objects and implementation objects.
         */

        /*
         ******************************************************************
         * BEGIN MODIFICATION AREA
         ******************************************************************
         * Put below code for creating implementation objects
         * and connecting them to the interface device objects.
         */

        // SYSTEM CORE
        // Create systemCore object and links between it and IO devices.
        
        SystemCore systemCore = new SystemCore();
       
        button.setSystemCore(systemCore);
        systemCore.setPassLight(light);
        // Create General objects
        
        Menu menu = new Menu();
        Rack rack = new Rack();
        List<TableConnection> tableConnections = new ArrayList<TableConnection>();
        
        // TABLE-RELATED
        for (int i = 1; i <= NUM_TABLES; i++) {
            
            String iString = Integer.toString(i);

            // This tableID is for later printing on tickets at the pass, in 
            // order to show which table is to receive the order.
            // Go look at the ReceiptPrinter class.
            
            // DO NOT CHANGE this scheme for naming table IDs.
            
            String tableID = "Tab-" + iString;

            // Create table-related core objects.
            // Connect these objects to table-related IO objects and to other system 
            // components.
            TableConnection tableConnection = new TableConnection("tc" + iString);
            tableConnection.setBankClient(bankClient);
            tableConnection.setCardReader(cardReaders.get(i-1));
            tableConnection.setReceiptPrinter(receiptPrinters.get(i-1));
            tableConnection.setTableDisplay(tableDisplays.get(i-1));
            tableDisplays.get(i-1).setTableConnection(tableConnection);
            tableConnections.add(tableConnection);
            
         }

        // GENERAL
        // Create implementation objects that link to more than one area
        // and add links between implementation objects and interface device
        // objects in different areas.
        
        officeKVM.setMenu(menu);
        for(int i = 0; i<tableDisplays.size(); i++)
        {
            tableDisplays.get(i).setMenu(menu);
            tableDisplays.get(i).setRack(rack);
            //tableDisplays.get(i).setClock(Clock);
            //tableDisplays.get(i).setInternetConnection(internet);
            tableDisplays.get(i).setCardReader(cardReaders.get(i));
            tableDisplays.get(i).setReceiptPrinter(receiptPrinters.get(i));
            tableDisplays.get(i).setBankClient(bankClient);
            
            
        }
        
        /*
         * Put above code for creating implementation objects
         * and connecting them to the interface device objects.
         ******************************************************************
         * END MODIFICATION AREA
         ******************************************************************
         */

        
    }
    
    
   
    
}
