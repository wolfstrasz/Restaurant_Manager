package roms;

public class TableConnection {
    
    private String tableConnectionName;
    private TableDisplay tableDisplay;
    private ReceiptPrinter receiptPrinter;
    private CardReader cardReader;
    private BankClient bankClient;
    
    
    TableConnection(String name)
    {
        tableConnectionName = name;
    }
    
    public void setTableDisplay(TableDisplay tableDisplay){
        this.tableDisplay = tableDisplay;
    }
    
    public void setReceiptPrinter(ReceiptPrinter receiptPrinter){
        this.receiptPrinter = receiptPrinter;
    }
    
    public void setCardReader(CardReader cardReader){
        this.cardReader = cardReader;
    }
    
    public void setBankClient(BankClient bankClient){
        this.bankClient = bankClient;
    }
    
    public String getInstanceName()
    {
        return tableConnectionName;
    }
    
    
}
