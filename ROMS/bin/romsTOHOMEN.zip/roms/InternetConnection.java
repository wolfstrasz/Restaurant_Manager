package roms;
import java.util.HashMap;
public class InternetConnection {
    
    private BankClient bankClient;
    
    // Store a connection from the name to the object
    private HashMap<String, ReceiptPrinter> allReceiptPrinters;
    private HashMap<String, TableDisplay> allTableDisplays;
    private HashMap<String, CardReader> allCardReaders;
    
    // Store a connection between 2 devices (by names)
    private HashMap<String,String>TDtoRP;
    private HashMap<String,String>TDtoCR;
    
    
    /*
    // Store info about order price.
    private HashMap<String,Money> allTotalPrices;
    
    // Store info about card details.
    private HashMap<String,String> allCardDetails;
    
    // Store info about authorisation codes;
    private HashMap<String,String> allAuthorisationCodes;
    */
    
    
    
    // Create connection between bankclient and internet.
    public void setBankClient(BankClient bankClient){
        this.bankClient = bankClient;
    }
    
    public void setTables(TableDisplay td, String tdName, 
                          ReceiptPrinter rp, String rpName, 
                          CardReader cr, String crName)
    {
        
    // Create connection between Internet and devices.
        allTableDisplays.put(tdName, td);
        allCardReaders.put(crName,cr);
        allReceiptPrinters.put(rpName, rp);
        
    // Create connection between devices.    
        TDtoRP.put(td.getInstanceName(), rp.getInstanceName());
        TDtoCR.put(td.getInstanceName(), cr.getInstanceName());
        
    }
    
    public void sendAmount(Money paymentAmount, String tableDisplay){
        
        CardReader cardReader = allCardReaders.get(TDtoCR.get(tableDisplay));
        ReceiptPrinter receiptPrinter = allReceiptPrinters.get(TDtoRP.get(tableDisplay));
        String cardDetails = cardReader.waitForCardDetails();
        String authorisationCode = bankClient.authorisePayment(cardDetails, paymentAmount);
        receiptPrinter.printReceipt(paymentAmount, authorisationCode);
        
    }
    

}
