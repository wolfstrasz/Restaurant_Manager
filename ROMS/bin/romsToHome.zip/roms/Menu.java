/**
 * 
 */
package roms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;
import java.util.List;

/**
 * @author pbj
 *
 */
public class Menu {
    /**
     * Format menu as list of strings, with, per menu item, 3 strings for 
     * respectively:
     * - MenuID
     * - Description
     * - Price
     * 
     * Items are expected to be ordered by MenuID.
     * 
     * An example list is:
     * 
     * "D1", "Wine",        "2.50",
     * "D2", "Soft drink",  "1.50",
     * "M1", "Fish",        "7.95",
     * "M2", "Veg chili",   "6.70"
     * 
     * These lists of strings are used by TableDisplay and TicketPrinter
     * to produce formatted ticket output messages.
     * 
     * @return
     */
    /* Store the menu in a map with key = ID and value = MenuItem */
	private HashMap<String,MenuItem> menu = new HashMap<String,MenuItem>();
	
	/* Getters */
	public MenuItem getMenuItem(String menuID){
	    assert menu.containsKey(menuID) 
	        : "An item with this ID does not exists in the menu.(getMenuItem)";
	    
	    return menu.get(menuID);
	}

    public HashMap<String,MenuItem> getMenu()
    {
        return menu;
    }
	
	/* Methods */
	public void addToMenu(String menuID, String description, Money price){
	    assert price.toString().contains("-") 
	        : "The price has to be a positive number";
	    
	    MenuItem item = new MenuItem(description,price);
	    menu.put(menuID, item);
	}
	
	public void removeFromMenu(String menuID){
	    assert menu.containsKey(menuID) 
	        : "An item with this ID does not exist in the menu.(removeFromMenu)";
	    
	    menu.remove(menuID);
	}
	
	public List<String> toStrings(){
	    List<String> menuList = new ArrayList<String>();
	    List<String> menuIDs  = new ArrayList<String>();
	    
	    // Extract all IDs
	    for (String menuID : menu.keySet()){
	        menuIDs.add(menuID);
	    }
	    
	    // Sort the IDs
	    menuIDs.sort(String::compareToIgnoreCase);
	    
	    // Iterate over the sorted IDs
	    for (int i=0; i < menuIDs.size(); i++){
	        String menuID = menuIDs.get(i);
	        MenuItem item = menu.get(menuID);
	        String price = item.getPrice().toString();
	        String description = item.getDescription();
	        
	        menuList.add(menuID);
	        menuList.add(description);
	        menuList.add(price);
	    }
	    return menuList;
	}
	   
}