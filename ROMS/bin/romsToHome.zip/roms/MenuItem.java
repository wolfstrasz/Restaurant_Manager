package roms;

public class MenuItem {
    
    /* Fields */
    private String description;
    private Money price;
    
    /* Constructors */
    MenuItem(String description, Money price){
        
        this.description = description;
        this.price = price;
    }
    
    /* Getters */
    String getDescription(){
        
        return description;
    }
    Money getPrice(){
        
        return price;
    }
}

