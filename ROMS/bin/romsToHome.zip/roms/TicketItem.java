package roms;

public class TicketItem {
    
    /* Fields */
    private String itemDesc;
    private Integer itemQuantity;
    private Integer itemReadyQuantity;
    
    /* Constructors */
    TicketItem (String desc){
        
        itemDesc = desc;
        itemQuantity = 1;
        itemReadyQuantity = 0;
    }
    
    /* Setters and Getters */
    public String getDesc (){
        
        return itemDesc;
    }
    
    public Integer getQuantity(){
        
        return itemQuantity;
    }
    
    public void setReady(){
        
        itemReadyQuantity ++;
    }
    
    public Integer getItemReadyQuantity(){
        
        return itemReadyQuantity;
    }
    
    /* Methods */
    public void addItem(){
        
        itemQuantity ++;
    }
    
    public void removeItem(){
        
        itemQuantity --;
    }

}
